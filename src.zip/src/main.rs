#[macro_use] extern crate rocket;

use rocket_db_pools::{Database, sqlx};

mod models;
mod db;
mod api;      
mod routes;   

#[derive(Database)]
#[database("sqlite_db")]
struct Db(sqlx::SqlitePool);

#[launch]
fn rocket() -> _ {
    rocket::build()
        .attach(Db::init())
        // Páginas HTML
        .mount("/", routes![
            routes::index::index,
            routes::books::books_index,
            routes::authors::authors_index,
            routes::tables::tables_index,
        ])
        // API JSON
        .mount("/api", routes![
            api::get_authors,
            api::get_author,
            api::create_author,
            api::update_author,
            api::delete_author,
            api::get_books,
            api::get_book,
            api::create_book,
            api::update_book,
            api::delete_book,
            api::get_reviews,
            api::get_review,
            api::create_review,
            api::update_review,
            api::delete_review,
            api::get_yearly_sales,
            api::get_yearly_sale,
            api::create_yearly_sales,
            api::update_yearly_sales,
            api::delete_yearly_sales,
            api::get_dashboard_stats,
        ])
}
